import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Wallet, Info, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function InvertirPage({ params }: { params: { id: string } }) {
  // Esto sería reemplazado por tu lógica para obtener el saldo de la moneda ficticia
  const saldoDisponible = 5000
  const nombreMoneda = "Tokens"

  return (
    <div className="container mx-auto py-6 max-w-3xl">
      <div className="mb-6">
        <Link
          href={`/proyectos/${params.id}`}
          className="flex items-center text-sm font-medium text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al Proyecto
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Invertir en New Project</CardTitle>
          <CardDescription>Utiliza tus {nombreMoneda} para invertir en este proyecto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Saldo disponible */}
          <div className="rounded-md bg-muted p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium">Saldo disponible</span>
              </div>
              <span className="text-lg font-semibold">
                {saldoDisponible} {nombreMoneda}
              </span>
            </div>
          </div>

          {/* Información del proyecto */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="overflow-hidden rounded-md">
              <Image
                src="/placeholder.svg?height=200&width=300"
                width={300}
                height={200}
                alt="Imagen del proyecto"
                className="h-[150px] w-full object-cover"
              />
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold">New Project</h3>
              <div className="grid grid-cols-1 gap-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Inversión Mínima:</span>
                  <span className="text-sm font-medium">100 {nombreMoneda}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Valor Total:</span>
                  <span className="text-sm font-medium">1,000 {nombreMoneda}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Rendimiento Anual:</span>
                  <span className="text-sm font-medium">10%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Monto de inversión */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Monto de inversión</h3>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <HelpCircle className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">La inversión mínima para este proyecto es de 100 {nombreMoneda}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="monto">Monto ({nombreMoneda})</Label>
                <span className="text-sm text-muted-foreground">Mínimo: 100</span>
              </div>
              <Input id="monto" type="number" min="100" max={saldoDisponible} step="10" defaultValue="100" />
              <Slider defaultValue={[100]} max={saldoDisponible} min={100} step={10} className="py-4" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>100 {nombreMoneda}</span>
                <span>
                  {saldoDisponible} {nombreMoneda}
                </span>
              </div>
            </div>
          </div>

          {/* Resumen de la inversión */}
          <div className="rounded-md border p-4">
            <h3 className="font-medium mb-3">Resumen de la inversión</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Monto a invertir:</span>
                <span className="text-sm font-medium">100 {nombreMoneda}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Rendimiento estimado anual:</span>
                <span className="text-sm font-medium">10 {nombreMoneda}</span>
              </div>
              <div className="border-t my-2"></div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Total después de 1 año:</span>
                <span className="text-sm font-medium">110 {nombreMoneda}</span>
              </div>
            </div>
          </div>

          <div className="rounded-md bg-blue-50 p-4 border border-blue-100">
            <div className="flex items-start">
              <Info className="mr-2 h-5 w-5 text-blue-500" />
              <div className="text-sm text-blue-700">
                <p>
                  Al invertir, aceptas los términos y condiciones del proyecto. Tu inversión se realizará utilizando tus{" "}
                  {nombreMoneda} disponibles.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" size="lg">
            Confirmar Inversión
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
