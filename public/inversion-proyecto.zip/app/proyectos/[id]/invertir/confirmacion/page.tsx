import Link from "next/link"
import { ArrowLeft, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ConfirmacionPage({ params }: { params: { id: string } }) {
  // Nombre de tu moneda ficticia
  const nombreMoneda = "Tokens"

  return (
    <div className="container mx-auto py-12 max-w-md">
      <div className="mb-6">
        <Link href="/inversiones" className="flex items-center text-sm font-medium text-gray-600 hover:text-gray-900">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver a Inversiones
        </Link>
      </div>

      <Card className="text-center">
        <CardHeader>
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <CheckCircle2 className="h-10 w-10 text-green-600" />
          </div>
          <CardTitle className="text-2xl">¡Inversión Exitosa!</CardTitle>
          <CardDescription>Has invertido correctamente en este proyecto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-md bg-muted p-4">
            <div className="space-y-3">
              <div className="space-y-1">
                <p className="text-muted-foreground text-sm">Proyecto</p>
                <p className="font-medium">New Project</p>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground text-sm">Fecha</p>
                <p className="font-medium">4/18/2025</p>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground text-sm">Monto Invertido</p>
                <p className="font-medium text-xl">100 {nombreMoneda}</p>
              </div>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            <p>Puedes ver el estado de tu inversión en la sección "Mis Inversiones".</p>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button className="w-full" asChild>
            <Link href="/inversiones">Ver Mis Inversiones</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/proyectos">Explorar Más Proyectos</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
