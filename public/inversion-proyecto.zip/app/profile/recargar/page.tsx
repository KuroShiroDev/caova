"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Building, Landmark, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function RecargarSaldoPage() {
  const [monto, setMonto] = useState<string>("100000")
  const [metodo, setMetodo] = useState<string>("pse")
  const [loading, setLoading] = useState<boolean>(false)

  const handleMontoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMonto(e.target.value)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulamos una carga
    setTimeout(() => {
      window.location.href = "/profile/recargar/confirmacion"
    }, 1500)
  }

  const montoOptions = [
    { value: "100000", label: "$ 100.000" },
    { value: "500000", label: "$ 500.000" },
    { value: "1000000", label: "$ 1.000.000" },
    { value: "5000000", label: "$ 5.000.000" },
    { value: "10000000", label: "$ 10.000.000" },
  ]

  return (
    <div className="container mx-auto py-6 max-w-3xl">
      <div className="mb-6">
        <Link href="/profile" className="flex items-center text-sm font-medium text-gray-600 hover:text-gray-900">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al Perfil
        </Link>
      </div>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Recargar Saldo</h1>
        <div className="flex items-center bg-blue-50 text-blue-700 px-4 py-2 rounded-md">
          <Wallet className="h-5 w-5 mr-2" />
          <span className="font-medium">Saldo actual: COP 9.305.917.990</span>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>¿Cuánto deseas recargar?</CardTitle>
            <CardDescription>Selecciona un monto predefinido o ingresa un valor personalizado</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Montos predefinidos */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {montoOptions.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={monto === option.value ? "default" : "outline"}
                  className="h-16"
                  onClick={() => setMonto(option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>

            {/* Monto personalizado */}
            <div className="space-y-2">
              <Label htmlFor="monto-personalizado">Monto personalizado (COP)</Label>
              <Input
                id="monto-personalizado"
                type="number"
                min="10000"
                step="10000"
                value={monto}
                onChange={handleMontoChange}
                className="text-lg"
              />
            </div>

            {/* Métodos de pago */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="font-medium text-lg">Método de pago</h3>

              <Tabs defaultValue="pse" value={metodo} onValueChange={setMetodo}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="pse">PSE</TabsTrigger>
                  <TabsTrigger value="tarjeta">Tarjeta</TabsTrigger>
                  <TabsTrigger value="efectivo">Efectivo</TabsTrigger>
                </TabsList>

                <TabsContent value="pse" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    <RadioGroup defaultValue="personal">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="personal" id="personal" />
                        <Label htmlFor="personal">Persona Natural</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="empresa" id="empresa" />
                        <Label htmlFor="empresa">Persona Jurídica</Label>
                      </div>
                    </RadioGroup>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="banco">Banco</Label>
                        <div className="relative">
                          <select
                            id="banco"
                            className="w-full h-10 pl-3 pr-10 text-base placeholder-gray-500 border rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          >
                            <option value="">Selecciona tu banco</option>
                            <option value="bancolombia">Bancolombia</option>
                            <option value="davivienda">Davivienda</option>
                            <option value="bbva">BBVA</option>
                            <option value="bogota">Banco de Bogotá</option>
                          </select>
                          <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                            <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                              <path
                                fillRule="evenodd"
                                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                clipRule="evenodd"
                              />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="documento">Documento</Label>
                        <Input id="documento" type="text" placeholder="Número de documento" />
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tarjeta" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="card-number">Número de tarjeta</Label>
                      <Input id="card-number" placeholder="1234 5678 9012 3456" />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="col-span-2 space-y-2">
                        <Label htmlFor="card-name">Nombre en la tarjeta</Label>
                        <Input id="card-name" placeholder="Nombre completo" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="card-cvv">CVV</Label>
                        <Input id="card-cvv" placeholder="123" maxLength={4} />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="card-month">Mes</Label>
                        <select
                          id="card-month"
                          className="w-full h-10 pl-3 pr-10 text-base placeholder-gray-500 border rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="">Mes</option>
                          {Array.from({ length: 12 }, (_, i) => i + 1).map((month) => (
                            <option key={month} value={month}>
                              {month.toString().padStart(2, "0")}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="card-year">Año</Label>
                        <select
                          id="card-year"
                          className="w-full h-10 pl-3 pr-10 text-base placeholder-gray-500 border rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="">Año</option>
                          {Array.from({ length: 10 }, (_, i) => new Date().getFullYear() + i).map((year) => (
                            <option key={year} value={year}>
                              {year}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="efectivo" className="space-y-4 pt-4">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="border-2 cursor-pointer hover:border-blue-500 transition-colors">
                        <CardContent className="flex flex-col items-center justify-center p-6">
                          <Building className="h-10 w-10 text-blue-600 mb-2" />
                          <h3 className="font-medium">Efecty</h3>
                        </CardContent>
                      </Card>

                      <Card className="border-2 cursor-pointer hover:border-blue-500 transition-colors">
                        <CardContent className="flex flex-col items-center justify-center p-6">
                          <Landmark className="h-10 w-10 text-blue-600 mb-2" />
                          <h3 className="font-medium">Baloto</h3>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="rounded-md bg-amber-50 p-4 border border-amber-100">
                      <p className="text-sm text-amber-800">
                        Al seleccionar pago en efectivo, generaremos un código que podrás utilizar en cualquier punto de
                        pago. La recarga se verá reflejada en tu cuenta una vez se confirme el pago.
                      </p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              {loading ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Procesando...
                </span>
              ) : (
                `Recargar COP ${Number.parseInt(monto).toLocaleString("es-CO")}`
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
