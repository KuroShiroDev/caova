import Link from "next/link"
import { ArrowLeft, CheckCircle, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ConfirmacionPage() {
  // Estos valores serían dinámicos en una implementación real
  const montoRecargado = "1.000.000"
  const fechaRecarga = "4 de mayo, 2025"
  const horaRecarga = "12:45 PM"
  const idTransaccion = "TRX-" + Math.floor(Math.random() * 1000000)
  const nuevoSaldo = "9.306.917.990"

  return (
    <div className="container mx-auto py-6 max-w-2xl">
      <div className="mb-6">
        <Link href="/profile" className="flex items-center text-sm font-medium text-gray-600 hover:text-gray-900">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al Perfil
        </Link>
      </div>

      <Card className="border-0 shadow-lg">
        <CardHeader className="text-center bg-green-50 rounded-t-lg border-b pb-6">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-800">¡Recarga Exitosa!</CardTitle>
          <CardDescription className="text-green-700">Tu saldo ha sido actualizado correctamente</CardDescription>
        </CardHeader>

        <CardContent className="pt-6 px-6">
          <div className="space-y-6">
            <div className="text-center">
              <p className="text-sm text-gray-500 mb-1">Monto recargado</p>
              <p className="text-3xl font-bold">COP {montoRecargado}</p>
            </div>

            <div className="border-t border-b py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">ID de Transacción</p>
                  <p className="font-medium">{idTransaccion}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Fecha</p>
                  <p className="font-medium">{fechaRecarga}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Hora</p>
                  <p className="font-medium">{horaRecarga}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Estado</p>
                  <p className="font-medium text-green-600">Completado</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 flex justify-between items-center">
              <div>
                <p className="text-sm text-blue-700">Nuevo saldo disponible</p>
                <p className="text-xl font-bold text-blue-800">COP {nuevoSaldo}</p>
              </div>
              <Button variant="outline" className="border-blue-200 text-blue-700 hover:bg-blue-100 hover:text-blue-800">
                <Download className="h-4 w-4 mr-2" />
                Comprobante
              </Button>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex flex-col space-y-3 px-6 pb-6">
          <Button className="w-full" asChild>
            <Link href="/proyectos">Explorar Proyectos</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/profile">Volver al Perfil</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
