import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Recargar Saldo | CAOVA",
  description: "Recarga tu saldo para invertir en proyectos inmobiliarios",
}

export default function RecargarLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-900 text-white py-4">
        <div className="container mx-auto px-4 flex items-center">
          <Link href="/">
            <div className="text-2xl font-bold">CAOVA</div>
          </Link>
          <nav className="hidden md:flex ml-10 space-x-8">
            <Link href="/proyectos" className="hover:text-blue-200">
              Proyectos
            </Link>
            <Link href="/quienes-somos" className="hover:text-blue-200">
              Quienes Somos
            </Link>
            <Link href="/blog" className="hover:text-blue-200">
              Blog
            </Link>
            <Link href="/admin" className="hover:text-blue-200">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main>{children}</main>
    </div>
  )
}

import Link from "next/link"
