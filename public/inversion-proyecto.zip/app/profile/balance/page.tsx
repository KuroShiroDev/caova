import { BalanceMovementsCard } from "@/components/balance/BalanceMovementsCard"

export default function BalancePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header similar al de tu aplicación */}
      <header className="bg-blue-900 text-white py-4">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="text-2xl font-bold">CAOVA</div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="hover:text-blue-200">
              Proyectos
            </a>
            <a href="#" className="hover:text-blue-200">
              Quienes Somos
            </a>
            <a href="#" className="hover:text-blue-200">
              Blog
            </a>
            <a href="#" className="hover:text-blue-200">
              Admin
            </a>
          </nav>
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-white rounded-full"></div>
            <div className="w-8 h-8 bg-white rounded-full"></div>
          </div>
        </div>
      </header>

      {/* Sección de perfil */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center">
                <span className="text-xl font-bold text-gray-600">JC</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold">Juan Camilo Echeverri Salazar</h1>
                <p className="text-gray-600">juancamiloecheverrisalazar@gmail.com</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Recargar saldo</button>
              <div className="text-right">
                <p className="text-2xl font-bold text-blue-900">COP 9.305.917.990</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="container mx-auto px-4 py-8">
        <BalanceMovementsCard basePath="profile" />
      </div>
    </div>
  )
}
