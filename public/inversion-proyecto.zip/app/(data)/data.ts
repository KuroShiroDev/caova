export const navigationMenuProfile = [
  {
    name: "Mis inversiones",
    value: "projects",
  },
  {
    name: "Balance y movimientos",
    value: "balance",
  },
  {
    name: "Editar perfil",
    value: "profile",
  },
]
