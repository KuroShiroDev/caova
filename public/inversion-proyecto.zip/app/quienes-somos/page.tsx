import { AboutUsHero } from "@/components/about/AboutUsHero"
import { AboutUsStats } from "@/components/about/AboutUsStats"
import { MissionVision } from "@/components/about/MissionVision"
import { CompanyValues } from "@/components/about/CompanyValues"
import { TeamSection } from "@/components/about/TeamSection"
import { CompanyHistory } from "@/components/about/CompanyHistory"
import { AchievementsSection } from "@/components/about/AchievementsSection"
import { TestimonialsSection } from "@/components/about/TestimonialsSection"
import { ContactCTA } from "@/components/about/ContactCTA"

export default function QuienesSomosPage() {
  return (
    <div className="min-h-screen">
      <AboutUsHero />
      <AboutUsStats />
      <MissionVision />
      <CompanyValues />
      <CompanyHistory />
      <TeamSection />
      <AchievementsSection />
      <TestimonialsSection />
      <ContactCTA />
    </div>
  )
}
