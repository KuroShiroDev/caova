import { BlogLayout } from "@/components/blog/BlogLayout"
import { BlogHero } from "@/components/blog/BlogHero"
import { BlogCategories } from "@/components/blog/BlogCategories"
import { FeaturedArticles } from "@/components/blog/FeaturedArticles"
import { RecentArticles } from "@/components/blog/RecentArticles"

export default function BlogPage() {
  return (
    <BlogLayout>
      <div className="space-y-12">
        <BlogHero />
        <BlogCategories />
        <FeaturedArticles />
        <RecentArticles />
      </div>
    </BlogLayout>
  )
}
