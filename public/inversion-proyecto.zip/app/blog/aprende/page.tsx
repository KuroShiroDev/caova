import { BlogLayout } from "@/components/blog/BlogLayout"
import { BlogSidebar } from "@/components/blog/BlogSidebar"
import { LearningContent } from "@/components/blog/LearningContent"

export default function AprendePage() {
  return (
    <BlogLayout>
      <div className="grid lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <BlogSidebar activeSection="aprende" />
        </div>
        <div className="lg:col-span-3">
          <LearningContent />
        </div>
      </div>
    </BlogLayout>
  )
}
