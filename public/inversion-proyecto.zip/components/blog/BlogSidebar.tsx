import { Card, CardContent } from "@/components/ui/card"
import { ChevronRight, BookOpen, HelpCircle, Home, TrendingUp } from "lucide-react"
import Link from "next/link"

interface BlogSidebarProps {
  activeSection?: string
}

export const BlogSidebar = ({ activeSection }: BlogSidebarProps) => {
  const navigationItems = [
    {
      id: "inicio",
      label: "Inicio",
      href: "/blog",
      icon: <Home className="h-4 w-4" />,
    },
    {
      id: "aprende",
      label: "Aprende",
      href: "/blog/aprende",
      icon: <BookOpen className="h-4 w-4" />,
    },
    {
      id: "faqs",
      label: "FAQs",
      href: "/blog/faqs",
      icon: <HelpCircle className="h-4 w-4" />,
    },
  ]

  const learningTopics = [
    "Inversiones inmobiliarias",
    "¿Cómo funciona la plataforma de inversión inmobiliaria de CAOVA?",
    "¿Cómo empezar a invertir en proyectos inmobiliarios con CAOVA?",
    "¿Cómo recargar saldo en tu cuenta de CAOVA?",
    "Tipos de proyectos inmobiliarios disponibles",
    "¿Cómo evaluar un proyecto inmobiliario?",
    "Retiros y ganancias en la plataforma de CAOVA",
    "Seguridad y transparencia en las inversiones",
    "¿Qué documentos necesito para invertir?",
    "Diversificación de portafolio inmobiliario",
  ]

  return (
    <div className="space-y-6">
      {/* Navigation */}
      <Card>
        <CardContent className="p-4">
          <nav className="space-y-2">
            {navigationItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                  activeSection === item.id ? "bg-blue-600 text-white" : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <div className="flex items-center space-x-3">
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                </div>
              </Link>
            ))}
          </nav>
        </CardContent>
      </Card>

      {/* Learning Topics - Only show when in aprende section */}
      {activeSection === "aprende" && (
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2 mb-4">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900">Temas de aprendizaje</h3>
              </div>

              <div className="space-y-2">
                {learningTopics.map((topic, index) => (
                  <button
                    key={index}
                    className="w-full text-left p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700 group-hover:text-blue-600">{topic}</span>
                      <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-blue-600" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Widget */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="text-center space-y-3">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
              <HelpCircle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h4 className="font-semibold text-blue-900">¿Necesitas ayuda?</h4>
              <p className="text-sm text-blue-700">Nuestro equipo está aquí para ayudarte</p>
            </div>
            <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
              Contactar soporte
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
