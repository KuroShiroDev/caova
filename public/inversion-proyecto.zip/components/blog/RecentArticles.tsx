import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, User, Calendar } from "lucide-react"

export const RecentArticles = () => {
  const recentArticles = [
    {
      title: "Nuevos proyectos disponibles en Medellín",
      description: "Descubre las últimas oportunidades de inversión en la ciudad de la eterna primavera.",
      category: "Proyectos",
      readTime: "5 min",
      author: "Ana Martínez",
      date: "24 May 2025",
      image: "/placeholder.svg?height=150&width=250",
    },
    {
      title: "Cómo diversificar tu portafolio inmobiliario",
      description: "Estrategias para distribuir el riesgo y maximizar retornos en tus inversiones.",
      category: "Estrategias",
      readTime: "7 min",
      author: "Luis Herrera",
      date: "23 May 2025",
      image: "/placeholder.svg?height=150&width=250",
    },
    {
      title: "Actualización de seguridad: Autenticación de dos factores",
      description: "Nueva funcionalidad para proteger mejor tu cuenta y tus inversiones.",
      category: "Seguridad",
      readTime: "3 min",
      author: "Patricia Vega",
      date: "22 May 2025",
      image: "/placeholder.svg?height=150&width=250",
    },
    {
      title: "Tendencias del mercado inmobiliario en Bogotá",
      description: "Análisis de precios, demanda y oportunidades en la capital colombiana.",
      category: "Mercado",
      readTime: "9 min",
      author: "Roberto Silva",
      date: "21 May 2025",
      image: "/placeholder.svg?height=150&width=250",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary mb-4">Artículos recientes</h2>
          <p className="text-gray-600">Mantente al día con las últimas novedades y consejos</p>
        </div>
        <Button variant="outline">Ver todos los artículos</Button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {recentArticles.map((article, index) => (
          <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
            <div className="md:flex">
              <div className="md:w-1/3">
                <img
                  src={article.image || "/placeholder.svg"}
                  alt={article.title}
                  className="w-full h-48 md:h-full object-cover"
                />
              </div>

              <CardContent className="md:w-2/3 p-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-xs">
                      {article.category}
                    </Badge>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      {article.readTime}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">{article.title}</h3>
                    <p className="text-gray-600 text-sm line-clamp-2">{article.description}</p>
                  </div>

                  <div className="flex items-center space-x-2 text-sm text-gray-500 pt-2">
                    <User className="h-4 w-4" />
                    <span>{article.author}</span>
                    <span>•</span>
                    <Calendar className="h-4 w-4" />
                    <span>{article.date}</span>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
