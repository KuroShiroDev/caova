import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, HelpCircle, CreditCard, Building2, Shield, TrendingUp } from "lucide-react"
import Link from "next/link"

export const BlogCategories = () => {
  const categories = [
    {
      title: "Primeros pasos",
      description: "Todo lo que necesitas saber para comenzar",
      icon: <BookOpen className="h-8 w-8 text-blue-600" />,
      articleCount: 8,
      href: "/blog/aprende",
      color: "bg-blue-50 border-blue-200",
    },
    {
      title: "Preguntas frecuentes",
      description: "Respuestas a las dudas más comunes",
      icon: <HelpCircle className="h-8 w-8 text-green-600" />,
      articleCount: 15,
      href: "/blog/faqs",
      color: "bg-green-50 border-green-200",
    },
    {
      title: "Pagos y recargas",
      description: "Cómo manejar tu dinero en la plataforma",
      icon: <CreditCard className="h-8 w-8 text-purple-600" />,
      articleCount: 6,
      href: "/blog/pagos",
      color: "bg-purple-50 border-purple-200",
    },
    {
      title: "Proyectos inmobiliarios",
      description: "Entiende los tipos de inversión disponibles",
      icon: <Building2 className="h-8 w-8 text-orange-600" />,
      articleCount: 12,
      href: "/blog/proyectos",
      color: "bg-orange-50 border-orange-200",
    },
    {
      title: "Seguridad",
      description: "Protege tu cuenta y tus inversiones",
      icon: <Shield className="h-8 w-8 text-red-600" />,
      articleCount: 5,
      href: "/blog/seguridad",
      color: "bg-red-50 border-red-200",
    },
    {
      title: "Estrategias de inversión",
      description: "Consejos para maximizar tus retornos",
      icon: <TrendingUp className="h-8 w-8 text-indigo-600" />,
      articleCount: 10,
      href: "/blog/estrategias",
      color: "bg-indigo-50 border-indigo-200",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-primary mb-4">Explora por categorías</h2>
        <p className="text-gray-600">Encuentra la información que necesitas de manera rápida y organizada</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category, index) => (
          <Link key={index} href={category.href}>
            <Card className={`hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${category.color}`}>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    {category.icon}
                    <Badge variant="secondary">{category.articleCount} artículos</Badge>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{category.title}</h3>
                    <p className="text-gray-600">{category.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
