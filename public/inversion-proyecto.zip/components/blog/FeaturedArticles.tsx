import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, User, ArrowRight } from "lucide-react"

export const FeaturedArticles = () => {
  const featuredArticles = [
    {
      title: "Guía completa para nuevos inversores en CAOVA",
      description: "Todo lo que necesitas saber para comenzar tu journey de inversión inmobiliaria desde cero.",
      image: "/placeholder.svg?height=200&width=400",
      category: "Primeros pasos",
      readTime: "10 min",
      author: "Equipo CAOVA",
      featured: true,
    },
    {
      title: "5 errores comunes al invertir en bienes raíces",
      description: "Aprende de los errores más frecuentes y cómo evitarlos para maximizar tus retornos.",
      image: "/placeholder.svg?height=200&width=400",
      category: "Estrategias",
      readTime: "8 min",
      author: "María González",
    },
    {
      title: "Análisis del mercado inmobiliario colombiano 2025",
      description: "Tendencias, oportunidades y proyecciones para el sector inmobiliario este año.",
      image: "/placeholder.svg?height=200&width=400",
      category: "Mercado",
      readTime: "12 min",
      author: "Carlos Rodríguez",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-primary mb-4">Artículos destacados</h2>
        <p className="text-gray-600">Los contenidos más populares y útiles para inversores</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {featuredArticles.map((article, index) => (
          <Card
            key={index}
            className={`overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 ${
              index === 0 ? "lg:col-span-2 lg:row-span-2" : ""
            }`}
          >
            <div className={`relative ${index === 0 ? "aspect-video" : "aspect-[4/3]"}`}>
              <img
                src={article.image || "/placeholder.svg"}
                alt={article.title}
                className="w-full h-full object-cover"
              />
              {article.featured && <Badge className="absolute top-4 left-4 bg-red-500 text-white">Destacado</Badge>}
            </div>

            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Badge variant="outline">{article.category}</Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {article.readTime}
                  </div>
                </div>

                <div>
                  <h3 className={`font-bold text-gray-900 mb-2 line-clamp-2 ${index === 0 ? "text-2xl" : "text-lg"}`}>
                    {article.title}
                  </h3>
                  <p className="text-gray-600 line-clamp-3">{article.description}</p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <User className="h-4 w-4" />
                    <span>{article.author}</span>
                  </div>
                  <ArrowRight className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
