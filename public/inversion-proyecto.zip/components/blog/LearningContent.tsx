import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Clock, User, Calendar } from "lucide-react"

export const LearningContent = () => {
  const articles = [
    {
      title: "¿Cómo funciona la plataforma de inversión inmobiliaria de CAOVA?",
      description:
        "Conoce paso a paso cómo nuestra plataforma te permite invertir en proyectos inmobiliarios de manera segura y transparente.",
      readTime: "5 min",
      category: "Fundamentos",
      author: "Equipo CAOVA",
      date: "24 May 2025",
      featured: true,
    },
    {
      title: "¿Cómo empezar a invertir en proyectos inmobiliarios con CAOVA?",
      description: "Guía completa para nuevos inversores: desde el registro hasta tu primera inversión.",
      readTime: "8 min",
      category: "Primeros pasos",
      author: "María González",
      date: "23 May 2025",
      featured: true,
    },
    {
      title: "¿Cómo recargar saldo en tu cuenta de CAOVA?",
      description: "Aprende todos los métodos disponibles para añadir fondos a tu cuenta: PSE, tarjetas y efectivo.",
      readTime: "4 min",
      category: "Pagos",
      author: "Carlos Rodríguez",
      date: "22 May 2025",
    },
    {
      title: "Tipos de proyectos inmobiliarios disponibles",
      description: "Descubre las diferentes opciones de inversión: residencial, comercial y mixto.",
      readTime: "6 min",
      category: "Proyectos",
      author: "Ana Martínez",
      date: "21 May 2025",
    },
    {
      title: "¿Cómo evaluar un proyecto inmobiliario?",
      description: "Criterios clave para tomar decisiones de inversión informadas y minimizar riesgos.",
      readTime: "10 min",
      category: "Estrategias",
      author: "Luis Herrera",
      date: "20 May 2025",
    },
    {
      title: "Retiros y ganancias en la plataforma de CAOVA",
      description: "Todo sobre cómo y cuándo puedes retirar tus ganancias de las inversiones.",
      readTime: "7 min",
      category: "Pagos",
      author: "Patricia Vega",
      date: "19 May 2025",
    },
    {
      title: "Seguridad y transparencia en las inversiones",
      description: "Conoce las medidas de seguridad que protegen tu dinero y tus datos personales.",
      readTime: "5 min",
      category: "Seguridad",
      author: "Roberto Silva",
      date: "18 May 2025",
    },
    {
      title: "¿Qué documentos necesito para invertir?",
      description: "Lista completa de documentos requeridos para verificar tu identidad y comenzar a invertir.",
      readTime: "3 min",
      category: "Primeros pasos",
      author: "Equipo CAOVA",
      date: "17 May 2025",
    },
    {
      title: "Diversificación de portafolio inmobiliario",
      description: "Estrategias para distribuir tus inversiones y reducir riesgos en tu portafolio.",
      readTime: "12 min",
      category: "Estrategias",
      author: "María González",
      date: "16 May 2025",
    },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-primary mb-4">Aprende sobre inversiones inmobiliarias</h1>
        <p className="text-gray-600">
          Guías completas y tutoriales paso a paso para dominar la plataforma CAOVA y maximizar tus inversiones.
        </p>
      </div>

      {/* Featured Articles */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">Artículos destacados</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {articles
            .filter((article) => article.featured)
            .map((article, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge className="bg-blue-100 text-blue-800">{article.category}</Badge>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-1" />
                        {article.readTime}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">{article.title}</h3>
                      <p className="text-gray-600 text-sm line-clamp-3">{article.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <User className="h-4 w-4" />
                        <span>{article.author}</span>
                        <span>•</span>
                        <Calendar className="h-4 w-4" />
                        <span>{article.date}</span>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {/* All Articles */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">Todos los artículos</h2>
        <div className="space-y-4">
          {articles.map((article, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline" className="text-xs">
                        {article.category}
                      </Badge>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-1" />
                        {article.readTime}
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold text-gray-900 hover:text-blue-600 transition-colors">
                      {article.title}
                    </h3>

                    <p className="text-gray-600 text-sm">{article.description}</p>

                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <User className="h-4 w-4" />
                      <span>{article.author}</span>
                      <span>•</span>
                      <Calendar className="h-4 w-4" />
                      <span>{article.date}</span>
                    </div>
                  </div>

                  <ChevronRight className="h-5 w-5 text-gray-400 ml-4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
