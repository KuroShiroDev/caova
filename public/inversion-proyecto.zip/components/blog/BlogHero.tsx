import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, BookOpen, HelpCircle, TrendingUp } from "lucide-react"

export const BlogHero = () => {
  return (
    <div className="text-center space-y-8">
      <div className="space-y-4">
        <Badge variant="outline" className="text-blue-600 border-blue-200">
          Centro de Ayuda CAOVA
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold text-primary">Aprende a invertir en bienes raíces</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Descubre cómo funciona nuestra plataforma, aprende sobre inversiones inmobiliarias y encuentra respuestas a
          todas tus preguntas.
        </p>
      </div>

      {/* Search Bar */}
      <div className="max-w-2xl mx-auto">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input placeholder="Buscar artículos, guías o preguntas frecuentes..." className="pl-12 pr-4 py-4 text-lg" />
          <Button className="absolute right-2 top-1/2 transform -translate-y-1/2">Buscar</Button>
        </div>
      </div>

      {/* Quick Access */}
      <div className="flex flex-wrap justify-center gap-4">
        <Button variant="outline" className="flex items-center space-x-2">
          <BookOpen className="h-4 w-4" />
          <span>Guías de inicio</span>
        </Button>
        <Button variant="outline" className="flex items-center space-x-2">
          <HelpCircle className="h-4 w-4" />
          <span>Preguntas frecuentes</span>
        </Button>
        <Button variant="outline" className="flex items-center space-x-2">
          <TrendingUp className="h-4 w-4" />
          <span>Consejos de inversión</span>
        </Button>
      </div>
    </div>
  )
}
