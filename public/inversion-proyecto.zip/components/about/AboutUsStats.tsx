import { Card, CardContent } from "@/components/ui/card"
import { MaxWidthWrapper } from "@/components/ui/maxWidthWrapper/MaxWidthWrapper"
import { Users, TrendingUp, Building2, Award, MapPin, Clock } from "lucide-react"

export const AboutUsStats = () => {
  const stats = [
    {
      number: "500+",
      label: "Inversores activos",
      description: "Personas confiando en CAOVA",
      icon: <Users className="h-8 w-8" />,
      color: "text-blue-600",
    },
    {
      number: "$50B+",
      label: "COP invertidos",
      description: "Capital total gestionado",
      icon: <TrendingUp className="h-8 w-8" />,
      color: "text-green-600",
    },
    {
      number: "25+",
      label: "Proyectos completados",
      description: "Desarrollos exitosos entregados",
      icon: <Building2 className="h-8 w-8" />,
      color: "text-purple-600",
    },
    {
      number: "98%",
      label: "Satisfacción del cliente",
      description: "Calificación promedio",
      icon: <Award className="h-8 w-8" />,
      color: "text-orange-600",
    },
    {
      number: "5",
      label: "Ciudades",
      description: "Presencia nacional",
      icon: <MapPin className="h-8 w-8" />,
      color: "text-red-600",
    },
    {
      number: "24/7",
      label: "Soporte",
      description: "Atención continua",
      icon: <Clock className="h-8 w-8" />,
      color: "text-indigo-600",
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <MaxWidthWrapper>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Números que hablan por nosotros</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Estas cifras reflejan nuestro compromiso y el crecimiento constante de nuestra comunidad de inversores.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="text-center p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <CardContent className="space-y-4">
                <div className={`flex justify-center ${stat.color}`}>{stat.icon}</div>
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-primary">{stat.number}</div>
                  <div className="font-semibold text-gray-900">{stat.label}</div>
                  <div className="text-sm text-gray-600">{stat.description}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </MaxWidthWrapper>
    </section>
  )
}
