import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MaxWidthWrapper } from "@/components/ui/maxWidthWrapper/MaxWidthWrapper"
import { ArrowRight, Mail, Phone, MapPin } from "lucide-react"
import Link from "next/link"

export const ContactCTA = () => {
  return (
    <section className="py-16 bg-white">
      <MaxWidthWrapper>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                ¿Listo para comenzar tu journey de inversión?
              </h3>
              <p className="text-gray-600 text-lg">
                Únete a cientos de inversionistas que ya están construyendo su futuro financiero con CAOVA. Comienza con
                tan solo $100.000 COP.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                <Link href="/register" className="flex items-center">
                  Crear cuenta gratis
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline">
                <Link href="/proyectos">Ver proyectos</Link>
              </Button>
            </div>

            <div className="space-y-4 pt-4">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-600" />
                <span className="text-gray-700">contacto@caova.co</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-600" />
                <span className="text-gray-700">+57 (1) 234-5678</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-blue-600" />
                <span className="text-gray-700">Bogotá, Medellín, Cali, Barranquilla, Cartagena</span>
              </div>
            </div>
          </div>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-8">
              <div className="space-y-6">
                <h4 className="text-2xl font-bold text-primary">¿Tienes preguntas?</h4>

                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg">
                    <h5 className="font-semibold text-gray-900 mb-2">Horarios de atención</h5>
                    <p className="text-gray-600 text-sm">
                      Lunes a Viernes: 8:00 AM - 6:00 PM
                      <br />
                      Sábados: 9:00 AM - 2:00 PM
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <h5 className="font-semibold text-gray-900 mb-2">Soporte 24/7</h5>
                    <p className="text-gray-600 text-sm">
                      Chat en línea disponible las 24 horas para consultas urgentes y soporte técnico.
                    </p>
                  </div>
                </div>

                <Button className="w-full" variant="outline">
                  <Link href="/contacto">Contactar un asesor</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </MaxWidthWrapper>
    </section>
  )
}
